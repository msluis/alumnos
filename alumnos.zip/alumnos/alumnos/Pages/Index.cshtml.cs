﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using System.IO;
using System.Net.Http.Headers;
using NPOI.SS.UserModel;
using Microsoft.AspNetCore.Hosting;
using System.Text;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;

namespace alumnos.Pages
{
    public class IndexModel : PageModel
    {

            private IHostingEnvironment _hostingEnvironment;
            public IndexModel(IHostingEnvironment hostingEnvironment)
            {
                _hostingEnvironment = hostingEnvironment;
            }
            public void OnGet()
        {

        }

 
    }
}
